<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Lumino - Login</title>
        <link href="<?= base_url() ?>includes/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?= base_url() ?>includes/css/datepicker3.css" rel="stylesheet">
        <link href="<?= base_url() ?>includes/css/styles.css" rel="stylesheet">
        <link href="<?= base_url() ?>includes/css/font-awesome.min.css" rel="stylesheet">

        <!--[if lt IE 9]>
        <script src="<?= base_url() ?>includes/js/html5shiv.js"></script>
        <script src="<?= base_url() ?>includes/js/respond.min.js"></script>
        <![endif]-->

    </head>
    <body onload="time()">
