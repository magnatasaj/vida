<script src="<?= base_url() ?>includes/js/jquery-1.11.1.min.js"></script>
	<script src="<?= base_url() ?>includes/js/bootstrap.min.js"></script>
</body>
</html>