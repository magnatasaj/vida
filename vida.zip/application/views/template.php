<html>
<body>
    <div id="contents">oiee</div>
    <div id="footer">Copyright 2008</div>
</body>
</html>
